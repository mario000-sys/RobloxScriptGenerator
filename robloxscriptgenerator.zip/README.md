# Roblox Script Generator

A locally-running desktop application that generates and executes Roblox Lua scripts using AI prompts with a conversation history feature.

## Features

- Generate Roblox Lua scripts using AI models
- Select different AI models for script generation
- Fallback templates when AI models aren't available
- Conversation history with previous scripts
- Syntax highlighting for Lua code
- Copy and execute generated scripts

## Requirements

To get the full functionality, you need to install Ollama on your local machine:

1. Download and install Ollama from: https://ollama.com/download
2. Pull the models you want to use (example: `ollama pull llama3` or `ollama pull llama3.2`)
3. Make sure Ollama is running when you start this application

## How to Run

1. Clone this repository
2. Install the required dependencies: `pip install -r requirements.txt`
3. Start the application: `python main.py`
4. Open your browser and go to: `http://localhost:5000`

## Usage

1. Select an AI model from the dropdown (if Ollama is running)
2. Enter a prompt describing the script you want to generate
3. Click "Generate Script" to create a Lua script
4. Review and edit the generated script in the editor
5. Click "Execute Script" to run it in Roblox
6. Use "Copy to Clipboard" to copy the script for other uses

## Template Scripts

If Ollama is not running, the application will fall back to built-in templates for:

- Flying scripts
- Teleportation
- Speed boost
- General purpose scripts

## Important Notes

- This application works best with Ollama running locally on your machine
- Without Ollama, the app will use built-in script templates
- Make sure Ollama is properly set up with models pulled before using