import os
import json
import logging
import ollama
from flask import Flask, render_template, request, jsonify, session, send_file
import uuid
import requests

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Path to store conversation history
HISTORY_DIR = "conversation_history"
os.makedirs(HISTORY_DIR, exist_ok=True)

# Available Ollama models
DEFAULT_MODEL = "llama3"
AVAILABLE_MODELS = [
    "llama3",
    "llama3.1",
    "llama3.2",
    "mistral",
    "gemma",
    "codellama",
    "llama2"
]

def is_ollama_running():
    """Check if Ollama is running locally."""
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=2)
        return response.status_code == 200
    except:
        return False
        
def get_available_models():
    """Get a list of available models from Ollama."""
    if not is_ollama_running():
        return []
        
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=2)
        if response.status_code == 200:
            data = response.json()
            if "models" in data:
                return [model["name"] for model in data["models"]]
        return AVAILABLE_MODELS
    except:
        return AVAILABLE_MODELS

def get_session_id():
    """Get or create a session ID for the current user."""
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    return session['session_id']

def load_conversation_history(session_id):
    """Load conversation history for a given session ID."""
    history_file = os.path.join(HISTORY_DIR, f"{session_id}.json")
    if os.path.exists(history_file):
        try:
            with open(history_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading conversation history: {str(e)}")
            return []
    return []

def save_conversation_history(session_id, history):
    """Save conversation history for a given session ID."""
    history_file = os.path.join(HISTORY_DIR, f"{session_id}.json")
    try:
        with open(history_file, 'w') as f:
            json.dump(history, f)
    except Exception as e:
        logger.error(f"Error saving conversation history: {str(e)}")

@app.route('/')
def index():
    """Render the main page."""
    session_id = get_session_id()
    history = load_conversation_history(session_id)
    
    # Check if Ollama is running and get available models
    ollama_available = is_ollama_running()
    models = get_available_models() if ollama_available else []
    
    # Use default models list if no models are found
    if not models:
        models = AVAILABLE_MODELS
    
    return render_template('index.html', 
                          history=history, 
                          models=models,
                          default_model=DEFAULT_MODEL,
                          ollama_running=ollama_available)
                          
@app.route('/download')
def download_page():
    """Render the download page."""
    return render_template('download.html')
    
@app.route('/download/package')
def download_package():
    """Create and download the application package."""
    import download_package
    try:
        zip_path = download_package.create_downloadable_package()
        return send_file(zip_path, as_attachment=True, download_name='roblox_script_generator.zip')
    except Exception as e:
        logger.error(f"Error creating package: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate', methods=['POST'])
def generate_script():
    """Generate Roblox Lua script based on the user prompt."""
    data = request.json
    prompt = data.get('prompt', '')
    model = data.get('model', DEFAULT_MODEL)
    
    if not prompt:
        return jsonify({'error': 'Prompt is required'}), 400
    
    session_id = get_session_id()
    history = load_conversation_history(session_id)
    
    try:
        # Prepare the prompt specifically for Roblox Lua
        lua_prompt = f"Generate a Roblox Lua script for the following: {prompt}. Only return the Lua code, no explanations."
        
        # Get history in the format expected by Ollama
        messages = []
        for entry in history:
            messages.append({'role': 'user', 'content': entry['prompt']})
            if 'response' in entry:
                messages.append({'role': 'assistant', 'content': entry['response']})
        
        # Add the current prompt
        messages.append({'role': 'user', 'content': lua_prompt})
        
        is_template = False
        used_model = model
        try:
            # Check if Ollama is running
            if not is_ollama_running():
                raise ConnectionError("Ollama is not running")
                
            # Call the Ollama model
            logger.info(f"Using Ollama model: {model}")
            response = ollama.chat(
                model=model,  # Use the model specified
                messages=messages
            )
            
            # Extract the script from the response
            script = response['message']['content']
        except (ConnectionError, ConnectionRefusedError):
            logger.error("Failed to connect to Ollama. Make sure Ollama is running locally.")
            # Fallback to a simple Lua script generator when Ollama is not available
            script = generate_fallback_script(prompt)
            is_template = True
            used_model = "template"
        except Exception as e:
            logger.error(f"Ollama error: {str(e)}")
            # Fallback to a simple Lua script generator when Ollama is not available
            script = generate_fallback_script(prompt)
            is_template = True
            used_model = "template"
        
        # Update history
        history.append({
            'prompt': prompt,
            'response': script,
            'timestamp': str(uuid.uuid1())
        })
        
        save_conversation_history(session_id, history)
        
        return jsonify({
            'script': script,
            'history': history,
            'is_template': is_template,
            'model': used_model
        })
    
    except Exception as e:
        logger.error(f"Error generating script: {str(e)}")
        return jsonify({'error': str(e)}), 500

def generate_fallback_script(prompt):
    """Generate a basic Lua script when Ollama is not available."""
    # Simple script templates based on common keywords in the prompt
    prompt = prompt.lower()
    
    if "fly" in prompt or "flying" in prompt:
        return """-- Simple Flying Script for Roblox
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")
local isFlying = false
local flySpeed = 50

-- Function to toggle flying
local function toggleFly()
    isFlying = not isFlying
    if isFlying then
        humanoid.PlatformStand = true
        local bodyVelocity = Instance.new("BodyVelocity")
        bodyVelocity.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
        bodyVelocity.Velocity = Vector3.new(0, 0, 0)
        bodyVelocity.Name = "FlyVelocity"
        bodyVelocity.Parent = character.HumanoidRootPart
    else
        humanoid.PlatformStand = false
        local bodyVelocity = character.HumanoidRootPart:FindFirstChild("FlyVelocity")
        if bodyVelocity then
            bodyVelocity:Destroy()
        end
    end
end

-- Connect the toggle to F key press
game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.F then
        toggleFly()
    end
end)

print("Flying script loaded! Press F to toggle flying.")"""
    
    elif "teleport" in prompt:
        return """-- Simple Teleport Script for Roblox
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()

-- Function to teleport to mouse position
local function teleportToMouse()
    local mouse = player:GetMouse()
    local targetPos = mouse.Hit.Position
    character:SetPrimaryPartCFrame(CFrame.new(targetPos + Vector3.new(0, 5, 0)))
end

-- Connect teleport to T key press
game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.T then
        teleportToMouse()
    end
end)

print("Teleport script loaded! Press T to teleport to cursor position.")"""
    
    elif "speed" in prompt or "fast" in prompt:
        return """-- Simple Speed Boost Script for Roblox
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")
local normalSpeed = 16
local boostSpeed = 50
local isBoosting = false

-- Function to toggle speed boost
local function toggleSpeedBoost()
    isBoosting = not isBoosting
    if isBoosting then
        humanoid.WalkSpeed = boostSpeed
    else
        humanoid.WalkSpeed = normalSpeed
    end
end

-- Connect the toggle to Shift key
game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.LeftShift then
        toggleSpeedBoost()
    end
end)

game:GetService("UserInputService").InputEnded:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.LeftShift and isBoosting then
        toggleSpeedBoost()
    end
end)

print("Speed boost script loaded! Hold Shift to activate.")"""
    
    else:
        return """-- Basic Roblox Lua Script Template
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")

-- Print confirmation message to output
print("Script loaded successfully!")

-- Set up basic player modifications
humanoid.WalkSpeed = 20  -- Default is 16
humanoid.JumpPower = 60  -- Default is 50

-- Connect a function to player input
game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed then
        if input.KeyCode == Enum.KeyCode.E then
            print("E key pressed!")
            -- Add your custom action here
        end
    end
end)

-- Main loop function
local function mainLoop()
    while true do
        -- Code that runs every second
        wait(1)
    end
end

-- Spawn the main loop
spawn(mainLoop)

print("Script is running. Press E to trigger an action.")"""

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get the conversation history for the current session."""
    session_id = get_session_id()
    history = load_conversation_history(session_id)
    return jsonify(history)

@app.route('/api/clear_history', methods=['POST'])
def clear_history():
    """Clear the conversation history for the current session."""
    session_id = get_session_id()
    save_conversation_history(session_id, [])
    return jsonify({'status': 'success'})

@app.route('/api/execute', methods=['POST'])
def execute_script():
    """
    This endpoint doesn't actually execute scripts in Roblox.
    Instead, it validates the script syntax and records the attempt.
    The actual execution must be done by the user in Roblox.
    """
    data = request.json
    script = data.get('script', '')
    
    if not script:
        return jsonify({'error': 'Script is required'}), 400
    
    try:
        # Log the copy/validation request
        logger.info("Script copy/validation requested by user")
        
        return jsonify({
            'status': 'success',
            'message': 'Script copied to clipboard',
            'note': 'This application does not directly execute scripts in Roblox. Please paste the script into your Roblox script executor.'
        })
    except Exception as e:
        logger.error(f"Error processing script: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
