// Initialize CodeMirror for code syntax highlighting
let scriptEditor;

document.addEventListener('DOMContentLoaded', () => {
    // Initialize CodeMirror
    scriptEditor = CodeMirror.fromTextArea(document.getElementById('script-output'), {
        mode: 'lua',
        theme: 'darcula',
        lineNumbers: true,
        indentUnit: 4,
        tabSize: 4,
        autoCloseBrackets: true,
        matchBrackets: true,
        readOnly: false
    });

    // Resize editor to fit content
    scriptEditor.setSize(null, 'auto');

    // Load conversation history
    loadHistory();

    // Set up event listeners
    document.getElementById('generate-form').addEventListener('submit', generateScript);
    document.getElementById('btn-execute').addEventListener('click', executeScript);
    document.getElementById('btn-copy').addEventListener('click', copyScript);
    document.getElementById('btn-clear-history').addEventListener('click', clearHistory);
});

async function generateScript(event) {
    event.preventDefault();
    
    const promptInput = document.getElementById('prompt-input');
    const modelSelect = document.getElementById('model-select');
    const prompt = promptInput.value.trim();
    const model = modelSelect ? modelSelect.value : "llama3";
    
    if (!prompt) {
        showAlert('Please enter a prompt', 'danger');
        return;
    }
    
    setLoading(true);
    
    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ prompt, model })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Clear the editor first
            scriptEditor.setValue('');
            
            // Add typing effect for the script
            typeScriptIntoEditor(data.script).then(() => {
                // Update the conversation history UI after typing effect completes
                updateHistoryUI(data.history);
            });
            
            // Clear the prompt input
            promptInput.value = '';
            
            // Scroll to bottom of history
            const conversationContainer = document.querySelector('.conversation-container');
            conversationContainer.scrollTop = conversationContainer.scrollHeight;
            
            // Show which model was used
            let modelInfo = "";
            if (data.is_template) {
                modelInfo = "Using built-in script template as Ollama is not available. For AI-generated scripts, install Ollama locally.";
                showAlert(modelInfo, 'warning');
            } else {
                modelInfo = `Generated using ${data.model} model`;
                showAlert(modelInfo, 'info');
            }
        } else {
            showAlert(`Error: ${data.error}`, 'danger');
        }
    } catch (error) {
        showAlert(`Error: ${error.message}`, 'danger');
    } finally {
        setLoading(false);
    }
}

async function executeScript() {
    const script = scriptEditor.getValue().trim();
    
    if (!script) {
        showAlert('No script to execute', 'warning');
        return;
    }
    
    setLoading(true);
    
    try {
        // Show a dialog explaining execution
        showAlert(`Note: To execute this script in Roblox, please copy the script and use your preferred injection method. This app doesn't directly connect to Roblox.`, 'info', 10000);
        
        // Log execution attempt on server
        const response = await fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ script })
        });
        
        const data = await response.json();
        
        // Copy to clipboard automatically for convenience
        await navigator.clipboard.writeText(script);
        showAlert('Script copied to clipboard for execution', 'success');
    } catch (error) {
        showAlert(`Error: ${error.message}`, 'danger');
    } finally {
        setLoading(false);
    }
}

function copyScript() {
    const script = scriptEditor.getValue().trim();
    
    if (!script) {
        showAlert('No script to copy', 'warning');
        return;
    }
    
    navigator.clipboard.writeText(script)
        .then(() => {
            showAlert('Script copied to clipboard', 'success');
        })
        .catch(err => {
            showAlert(`Error copying to clipboard: ${err.message}`, 'danger');
        });
}

async function loadHistory() {
    try {
        const response = await fetch('/api/history');
        const history = await response.json();
        
        updateHistoryUI(history);
    } catch (error) {
        showAlert(`Error loading history: ${error.message}`, 'danger');
    }
}

async function clearHistory() {
    try {
        const response = await fetch('/api/clear_history', {
            method: 'POST'
        });
        
        if (response.ok) {
            const conversationContainer = document.querySelector('.conversation-container');
            conversationContainer.innerHTML = '';
            
            showAlert('Conversation history cleared', 'success');
        } else {
            const data = await response.json();
            showAlert(`Error: ${data.error}`, 'danger');
        }
    } catch (error) {
        showAlert(`Error: ${error.message}`, 'danger');
    }
}

function updateHistoryUI(history) {
    const conversationContainer = document.querySelector('.conversation-container');
    conversationContainer.innerHTML = '';
    
    history.forEach(entry => {
        // Add user message
        const userDiv = document.createElement('div');
        userDiv.className = 'chat-message user-message';
        userDiv.innerHTML = `
            <strong>You:</strong>
            <div>${escapeHtml(entry.prompt)}</div>
        `;
        conversationContainer.appendChild(userDiv);
        
        // Add AI response
        if (entry.response) {
            const aiDiv = document.createElement('div');
            aiDiv.className = 'chat-message ai-message';
            aiDiv.innerHTML = `
                <strong>AI:</strong>
                <pre class="mb-0"><code class="language-lua">${escapeHtml(entry.response)}</code></pre>
                <div class="mt-2">
                    <button class="btn btn-sm btn-secondary copy-response-btn" data-response="${escapeHtml(entry.response)}">
                        <i class="fas fa-copy"></i> Copy
                    </button>
                    <button class="btn btn-sm btn-success use-script-btn" data-response="${escapeHtml(entry.response)}">
                        <i class="fas fa-code"></i> Use Script
                    </button>
                </div>
            `;
            conversationContainer.appendChild(aiDiv);
        }
    });
    
    // Add event listeners to the new buttons
    document.querySelectorAll('.copy-response-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const script = this.getAttribute('data-response');
            navigator.clipboard.writeText(script)
                .then(() => {
                    showAlert('Script copied to clipboard', 'success');
                })
                .catch(err => {
                    showAlert(`Error copying to clipboard: ${err.message}`, 'danger');
                });
        });
    });
    
    document.querySelectorAll('.use-script-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const script = this.getAttribute('data-response');
            // Clear editor first
            scriptEditor.setValue('');
            // Use typing effect
            typeScriptIntoEditor(script).then(() => {
                showAlert('Script loaded in the editor', 'success');
            });
        });
    });
    
    // Apply syntax highlighting to code
    document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });
}

function setLoading(isLoading) {
    const generateBtn = document.getElementById('btn-generate');
    const spinner = document.querySelector('.loading-spinner');
    
    if (isLoading) {
        generateBtn.disabled = true;
        generateBtn.classList.add('loading');
        spinner.style.display = 'inline-block';
    } else {
        generateBtn.disabled = false;
        generateBtn.classList.remove('loading');
        spinner.style.display = 'none';
    }
}

function showAlert(message, type, duration = 5000) {
    const alertsContainer = document.getElementById('alerts-container');
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    alertsContainer.appendChild(alertDiv);
    
    // Auto-dismiss after specified duration
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => {
            alertDiv.remove();
        }, 150);
    }, duration);
}

// Function to display text with a typing effect
async function typeScriptIntoEditor(text) {
    return new Promise(resolve => {
        let i = 0;
        const lines = text.split('\n');
        let currentText = '';
        
        // Display lines with a typing effect
        const typeInterval = setInterval(() => {
            if (i < lines.length) {
                currentText += lines[i] + '\n';
                scriptEditor.setValue(currentText);
                
                // Scroll to the current line being typed
                scriptEditor.scrollIntoView({line: i, ch: 0});
                
                i++;
            } else {
                clearInterval(typeInterval);
                resolve();
            }
        }, 50); // Adjust speed here - lower = faster typing
    });
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
