import os
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class ConversationManager:
    """
    Class to handle conversation history management
    """
    def __init__(self, history_dir="conversation_history"):
        self.history_dir = history_dir
        os.makedirs(self.history_dir, exist_ok=True)
    
    def load_conversation(self, session_id):
        """
        Load conversation history for a specific session
        
        Args:
            session_id (str): Unique identifier for the session
            
        Returns:
            list: Conversation history for the session
        """
        history_file = os.path.join(self.history_dir, f"{session_id}.json")
        if not os.path.exists(history_file):
            return []
        
        try:
            with open(history_file, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading conversation history: {str(e)}")
            return []
    
    def save_conversation(self, session_id, history):
        """
        Save conversation history for a specific session
        
        Args:
            session_id (str): Unique identifier for the session
            history (list): Conversation history to save
            
        Returns:
            bool: True if successful, False otherwise
        """
        history_file = os.path.join(self.history_dir, f"{session_id}.json")
        try:
            with open(history_file, "w") as f:
                json.dump(history, f)
            return True
        except Exception as e:
            logger.error(f"Error saving conversation history: {str(e)}")
            return False
    
    def add_entry(self, session_id, prompt, response=None):
        """
        Add a new entry to the conversation history
        
        Args:
            session_id (str): Unique identifier for the session
            prompt (str): User prompt
            response (str, optional): AI response
            
        Returns:
            list: Updated conversation history
        """
        history = self.load_conversation(session_id)
        
        entry = {
            "prompt": prompt,
            "timestamp": datetime.now().isoformat()
        }
        
        if response is not None:
            entry["response"] = response
        
        history.append(entry)
        self.save_conversation(session_id, history)
        
        return history
    
    def clear_conversation(self, session_id):
        """
        Clear conversation history for a specific session
        
        Args:
            session_id (str): Unique identifier for the session
            
        Returns:
            bool: True if successful, False otherwise
        """
        return self.save_conversation(session_id, [])
    
    def get_all_sessions(self):
        """
        Get a list of all session IDs
        
        Returns:
            list: List of session IDs
        """
        try:
            session_files = [f for f in os.listdir(self.history_dir) if f.endswith(".json")]
            session_ids = [os.path.splitext(f)[0] for f in session_files]
            return session_ids
        except Exception as e:
            logger.error(f"Error getting session list: {str(e)}")
            return []
